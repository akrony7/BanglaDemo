বাংলা ডেমো Android APK তৈরির নির্দেশনা

১) GitHub-এ লগইন করে New repository তৈরি করুন; নাম দিন BanglaDemo।
২) ZIP-এর ভেতরের সব ফাইল ও ফোল্ডার repository-র main branch-এ upload করুন।
৩) Actions tab খুলে 'Build Android APK' workflow নির্বাচন করুন।
৪) 'Run workflow' চাপুন। Build সফল হলে workflow run-এর নিচে Artifacts থেকে
   BanglaDemo-debug-apk.zip ডাউনলোড করুন।
৫) ZIP extract করে app-debug.apk ফোনে খুলুন। Android চাইলে 'Install unknown apps'
   অনুমতি দিন। শুধু নিজের তৈরি/বিশ্বস্ত APK ইনস্টল করবেন।

এটি debug APK; Play Store release-এর জন্য signed release build নয়।
